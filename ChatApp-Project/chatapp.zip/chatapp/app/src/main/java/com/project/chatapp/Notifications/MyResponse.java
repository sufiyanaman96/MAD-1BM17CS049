package com.project.chatapp.Notifications;

public class MyResponse {

    public int success;
}
