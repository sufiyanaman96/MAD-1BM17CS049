package com.project.chatapp.Model;

public class AllMethods {
    public static String name="";
}
